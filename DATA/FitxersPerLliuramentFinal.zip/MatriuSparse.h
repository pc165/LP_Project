#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <map>
#include "Tree.hpp"
using namespace std;


class MatriuSparse
{
public:
	//AFEGIR EL VOSTRE CODI
	void clear();
private:
	//AFEGIR EL VOSTRE CODI
};

