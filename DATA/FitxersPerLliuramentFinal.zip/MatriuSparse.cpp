#include "MatriuSparse.h"



void MatriuSparse::clear()
{
	//Heu de fer clear de totes les estructures stl
	//i deixar l'estructura buida
}

//AFEGIR LA RESTA DE LA VOSTRA CLASSE